# acid-db

# Releases

**0.3.4**
 + DBTable.OrderBy now uses a stable sort

**0.3.2**
 + Improved typeScript Support

**0.3.1**
 + Added typeScript Support
