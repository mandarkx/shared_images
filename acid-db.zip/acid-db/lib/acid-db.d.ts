/**
 * Created by sam_g on 6/3/2017.
 */
import { DBTable } from "./DBTable";
export { DBTable } from "./DBTable";
export { CachingDBTable } from "./CachingDBTable";
export default DBTable;
